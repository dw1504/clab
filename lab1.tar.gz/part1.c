// Assign the value of 5 to the integer variable pointed
// to by ptr.
//
// This should only take one line of code!
void
set_to_five(int *ptr)
{
  *ptr=5;	//assign the value of 5
}
